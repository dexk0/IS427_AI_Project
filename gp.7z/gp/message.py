def preprocess_data(data):
    """
    This function preprocesses the data as needed and gets the attributes and labels from the preprocessed data

    parameter: a data file 
    returns: the encoded attributes and labels from the data 
    """
    
    
    NumColum = data.select_dtypes(include=[np.number]).columns ##Selects columns that have a data type that is a number 

    if data[NumColum].isnull().any().any():##checks if there are any missing values in any columns in any rows inside the data set (.any.any = 2D)
        data[NumColum] = data[NumColum].fillna(data[NumColum].mean()) ##replace those missing values with the mean of the other numerical column values in the data set
    
    if not data[NumColum].empty: ##checks if the data's numerical column is not empty
        zScore = np.abs(stats.zscore(data[NumColum])) # Calculate z-scores and filter out outliers
        data = data[(zScore < 3).all(axis=1)] ##based on the z-score, remove the outlier. (an outlier is if its z-score is greater than 3)
    
    if not data[NumColum].empty: ##checks and sees if the numerical column values in the data set are empty 
        DataNorm = MinMaxScaler() ##Calls MinMaxScaler, this scales the data to a given range (0 - 1)
        data[NumColum] = DataNorm.fit_transform(data[NumColum]) ##applys the MinMaxScaler to the number data values and replaces them (this essentially further cleans up the data)
    
    cate_columns = data.select_dtypes(include=[object]).columns ##finds and stores objects in the column of the data (categorical)

    for c in cate_columns: ## goes in and looks at each column in cate_columns
        lable_encode = LabelEncoder() ##calls in the label encoder function
        data[c] = lable_encode.fit_transform(data[c]) ## applys the LabelEncoder function to the data values and replaces them
    
     ##iloc slices the dataframe and ':' selects all rows and :-1 means it selects all rows but the last value
    attributes = data.iloc[:, :-1]  # All columns except the last one as attributes

     ##iloc slices the dataframe and ':' selects all rows and :-1 means it selects all rows but the last value
    labels = data.iloc[:, -1] # The last column as labels

    return attributes, labels
